
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	export interface AppTypes {
		RouteId(): "/" | "/__tests__" | "/api" | "/api/summary" | "/api/summary/suggestion" | "/api/summary/suggestion/__tests__" | "/api/templates" | "/api/templates/clipboard" | "/api/templates/summary" | "/day" | "/day/[date]" | "/day/[date]/__tests__" | "/day/[date]/events" | "/day/[date]/raw" | "/day/[date]/raw/__tests__" | "/day/[date]/stream" | "/day/[date]/summary" | "/day/[date]/summary/__tests__" | "/settings";
		RouteParams(): {
			"/day/[date]": { date: string };
			"/day/[date]/__tests__": { date: string };
			"/day/[date]/events": { date: string };
			"/day/[date]/raw": { date: string };
			"/day/[date]/raw/__tests__": { date: string };
			"/day/[date]/stream": { date: string };
			"/day/[date]/summary": { date: string };
			"/day/[date]/summary/__tests__": { date: string }
		};
		LayoutParams(): {
			"/": { date?: string };
			"/__tests__": Record<string, never>;
			"/api": Record<string, never>;
			"/api/summary": Record<string, never>;
			"/api/summary/suggestion": Record<string, never>;
			"/api/summary/suggestion/__tests__": Record<string, never>;
			"/api/templates": Record<string, never>;
			"/api/templates/clipboard": Record<string, never>;
			"/api/templates/summary": Record<string, never>;
			"/day": { date?: string };
			"/day/[date]": { date: string };
			"/day/[date]/__tests__": { date: string };
			"/day/[date]/events": { date: string };
			"/day/[date]/raw": { date: string };
			"/day/[date]/raw/__tests__": { date: string };
			"/day/[date]/stream": { date: string };
			"/day/[date]/summary": { date: string };
			"/day/[date]/summary/__tests__": { date: string };
			"/settings": Record<string, never>
		};
		Pathname(): "/" | "/__tests__" | "/__tests__/" | "/api" | "/api/" | "/api/summary" | "/api/summary/" | "/api/summary/suggestion" | "/api/summary/suggestion/" | "/api/summary/suggestion/__tests__" | "/api/summary/suggestion/__tests__/" | "/api/templates" | "/api/templates/" | "/api/templates/clipboard" | "/api/templates/clipboard/" | "/api/templates/summary" | "/api/templates/summary/" | "/day" | "/day/" | `/day/${string}` & {} | `/day/${string}/` & {} | `/day/${string}/__tests__` & {} | `/day/${string}/__tests__/` & {} | `/day/${string}/events` & {} | `/day/${string}/events/` & {} | `/day/${string}/raw` & {} | `/day/${string}/raw/` & {} | `/day/${string}/raw/__tests__` & {} | `/day/${string}/raw/__tests__/` & {} | `/day/${string}/stream` & {} | `/day/${string}/stream/` & {} | `/day/${string}/summary` & {} | `/day/${string}/summary/` & {} | `/day/${string}/summary/__tests__` & {} | `/day/${string}/summary/__tests__/` & {} | "/settings" | "/settings/";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): string & {};
	}
}